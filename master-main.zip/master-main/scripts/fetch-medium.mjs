// Fetches the Medium RSS feed and writes posts.json — no external dependencies.
// Runs in GitHub Actions (Node 20+, global fetch). Server-side, so no CORS / rss2json needed.

const FEED = "https://medium.com/feed/@raquelhipolito";

function pick(block, tag) {
  const m = block.match(new RegExp("<" + tag + "[^>]*>([\\s\\S]*?)<\\/" + tag + ">"));
  if (!m) return "";
  return m[1].replace(/<!\[CDATA\[/g, "").replace(/\]\]>/g, "").trim();
}

function firstImg(html) {
  const m = (html || "").match(/<img[^>]+src=["']([^"']+)["']/i);
  return m ? m[1] : "";
}

async function main() {
  const res = await fetch(FEED, { headers: { "User-Agent": "Mozilla/5.0 (compatible; MediumSync/1.0)" } });
  if (!res.ok) throw new Error("Feed fetch failed: " + res.status);
  const xml = await res.text();

  const blocks = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((m) => m[1]);
  const items = blocks.map((b) => {
    const content = pick(b, "content:encoded") || pick(b, "description");
    return {
      title: pick(b, "title"),
      link: (pick(b, "link") || "").split("?")[0],
      pubDate: pick(b, "pubDate"),
      description: content,
      thumbnail: firstImg(content),
    };
  }).filter((it) => it.title && it.link);

  const out = { updated: new Date().toISOString(), source: FEED, items };

  const fs = await import("node:fs/promises");
  await fs.writeFile("posts.json", JSON.stringify(out, null, 2) + "\n");
  console.log("Wrote posts.json with " + items.length + " item(s).");
}

main().catch((e) => { console.error(e); process.exit(1); });
